﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Morse_Code_Translator
{
    internal class Program
    {
        static void TitleHeader()
        {
            Console.WriteLine("-------------------------------" + "||   Morse Code Translator   ||" + "-------------------------------\n");
        }
        static void DictionaryUI()
        {
            Console.Clear();

            TitleHeader();
            Console.WriteLine("Letters: " + "                " + "      Numbers & Symbols:");

            Console.WriteLine("A = .-   " + "       N = -.   " + "  ||  1 = .----" + "      *Space* = to divide letters");
            Console.WriteLine("B = -... " + "       O = ---  " + "  ||  2 = ..---" + "            / = to divide words  ");
            Console.WriteLine("C = -.-. " + "       P = .--. " + "  ||  3 = ...--");
            Console.WriteLine("D = -..  " + "       Q = --.- " + "  ||  4 = ....-");
            Console.WriteLine("E = .    " + "       R = .-.  " + "  ||  5 = .....");
            Console.WriteLine("F = ..-. " + "       S = ...  " + "  ||  6 = -....");
            Console.WriteLine("G = --.  " + "       T = -    " + "  ||  7 = --...");
            Console.WriteLine("H = .... " + "       U = ..-  " + "  ||  8 = ---..");
            Console.WriteLine("I = ..   " + "       V = ...- " + "  ||  9 = ----.");
            Console.WriteLine("J = .--- " + "       W = .--  " + "  ||  0 = -----");
            Console.WriteLine("K = -.-  " + "       X = -..- " + "  ||           ");
            Console.WriteLine("L = .-.. " + "       Y = -.-- " + "  ||           ");
            Console.WriteLine("M = --   " + "       Z = --.. " + "  ||           ");
        }

        static void MainMenu()
        {
            TitleHeader();
            DictionaryUI();
        }

        static void Translator()
        {


        }


        static void ExitScreen()
        {

        }

        static void Main(string[] args)
        {
        }
    }
}