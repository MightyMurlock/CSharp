﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MorseCodeTrDictTest
{
    //class MyClass
    //{
    //    private Dictionary<string, int> myDict = new Dictionary<string, int>();

    //    public void AddToDict(string key, int value)
    //    {
    //        myDict.Add(key, value);
    //    }

    //    public int GetValueFromDict(string key)
    //    {
    //        return myDict[key];
    //    }
    //}
    //internal class Program
    //{
    //    static void Main(string[] args)
    //    {
    //        MyClass myClassInstance = new MyClass();
    //        myClassInstance.AddToDict("foo", 42);
    //        int value = myClassInstance.GetValueFromDict("foo");
    //        Console.WriteLine(value);
    //    }


    //}

    //class Dictionary
    //{
    //    public Dictionary<string, string> morseCodeDict = new Dictionary<string, string>();

    //    public void DictionaryValues()
    //    {
    //        morseCodeDict.Add("---", "O");
    //        morseCodeDict.Add("O", "---");
    //        morseCodeDict.Add("...", "S");
    //        morseCodeDict.Add("S", "...");
    //    }

    //    public string GetDictionaryValue(string key)
    //    {
    //        return morseCodeDict[key];
    //    }
    //}

    //internal class Program
    //{
    //    static void Translator()
    //    {
    //        Dictionary dictionaryInstance = new Dictionary();

    //        string input = Console.ReadLine();

    //        for (int i = 0; i < input.Length; i++)
    //        {
    //            char letter = input[i];

    //            if (letter == ' ')
    //            {
    //                Console.Write(" /");
    //            }
    //            else
    //            {
    //                Console.Write(dictionaryInstance.GetDictionaryValue(letter.ToString()));
    //            }

    //            Console.Write(" ");
    //        }
    //        Console.WriteLine();
    //    }

    //    static void Main(string[] args)
    //    {
    //        Translator();
    //    }
    //}

    class MyClass
    {
        private Dictionary<string, string> myDict = new Dictionary<string, string>();

        public MyClass()
        {
            //myDict.Add(key, value);

            myDict.Add("S", "...");
            myDict.Add("...", "S");
            myDict.Add("O", "---");
            myDict.Add("---", "O");
        }

        public string GetValueFromDict(string key)
        {
            return myDict[key];
        }
    }

    class Program
    {
        static void Translator()
        {
            MyClass myClassInstance = new MyClass();

            //Console.WriteLine("input");
            //string value = myClassInstance.GetValueFromDict(Console.ReadLine());

            //Console.WriteLine(value);


            string input = Console.ReadLine();

            for (int i = 0; i < input.Length; i++)
            {
                char letter = input[i];


                if (letter == ' ')
                {
                    Console.Write(" /");
                }
                else
                {
                    Console.Write(myClassInstance.GetValueFromDict(letter.ToString()));
                }
                Console.Write(" ");
            }
            Console.WriteLine();
        }
        
        static void Main(string[] args)
        {
            Translator();
        }
    }





}
