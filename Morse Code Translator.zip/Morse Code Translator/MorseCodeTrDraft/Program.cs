﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MorseCodeTrDraft
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> morseCodeDict = new Dictionary<string, string>();
            morseCodeDict.Add("---", "O");
            morseCodeDict.Add("O", "---");
            morseCodeDict.Add("...", "S");
            morseCodeDict.Add("S", "...");

            //Console.WriteLine(morseCodeDict[Console.ReadLine()]);

            string input = Console.ReadLine();

            for (int i = 0; i < input.Length; i++)
            {
                char letter = input[i];
                

                if (letter == ' ')
                {
                    Console.Write(" /");
                }
                else 
                {
                    Console.Write(morseCodeDict[letter.ToString()]);
                }

                Console.Write(" ");
            }
            Console.WriteLine();





        }
    }
}
